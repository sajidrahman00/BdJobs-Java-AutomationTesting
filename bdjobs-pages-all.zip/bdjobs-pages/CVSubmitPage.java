package com.bdjobs.automation.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class CVSubmitPage {
    WebDriver driver;

    By cvUploadButton = By.id("btnUpload");
    By submitButton = By.id("btnSubmit");

    public CVSubmitPage(WebDriver driver) {
        this.driver = driver;
    }

    public void uploadCV(String filePath) {
        driver.findElement(cvUploadButton).sendKeys(filePath);
    }

    public void clickSubmit() {
        driver.findElement(submitButton).click();
    }
}
