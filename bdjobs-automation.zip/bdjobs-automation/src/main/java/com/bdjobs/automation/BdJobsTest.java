package com.bdjobs.automation;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.apache.commons.io.FileUtils;

import java.io.File;
import java.io.IOException;
import java.time.Duration;

// Utility Class for Screenshot
class ScreenshotUtil {
    public static void takeScreenshot(WebDriver driver, String fileName) {
        TakesScreenshot ts = (TakesScreenshot) driver;
        File src = ts.getScreenshotAs(OutputType.FILE);
        try {
            FileUtils.copyFile(src, new File("./screenshots/" + fileName + ".png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

// Page Object: HomePage
class HomePage {
    WebDriver driver;
    By searchBox = By.id("txtKeyword");
    By searchButton = By.id("btnSearch");

    public HomePage(WebDriver driver) {
        this.driver = driver;
    }

    public void enterKeyword(String keyword) {
        driver.findElement(searchBox).sendKeys(keyword);
    }

    public void clickSearch() {
        driver.findElement(searchButton).click();
    }
}

// Page Object: SearchResultsPage
class SearchResultsPage {
    WebDriver driver;

    public SearchResultsPage(WebDriver driver) {
        this.driver = driver;
    }

    public String getPageTitle() {
        return driver.getTitle();
    }
}

// Main Test Class
public class BdJobsTest {
    public static void main(String[] args) {

        System.setProperty("webdriver.chrome.driver", "path/to/chromedriver");

        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

        try {
            driver.get("https://www.bdjobs.com/");
            ScreenshotUtil.takeScreenshot(driver, "HomePage");

            HomePage homePage = new HomePage(driver);
            homePage.enterKeyword("Software Engineer");
            ScreenshotUtil.takeScreenshot(driver, "KeywordEntered");

            homePage.clickSearch();
            ScreenshotUtil.takeScreenshot(driver, "SearchResults");

            SearchResultsPage resultsPage = new SearchResultsPage(driver);
            System.out.println("Search Results Page Title: " + resultsPage.getPageTitle());

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            driver.quit();
        }
    }
}
